<?php

namespace Andy\DeletePostsByUsername\Pub\Controller;

use XF\Pub\Controller\AbstractController;

class DeletePostsByUsername extends AbstractController
{
	public function actionIndex()
	{
		// check permission
		if (!\XF::visitor()->is_admin)
		{
			return $this->noPermission();
		}

		// send to template
		return $this->view('Andy\DeletePostsByUsername:Index', 'andy_delete_posts_by_username');
	}
	
	public function actionConfirm()
	{
		// check permission
		if (!\XF::visitor()->is_admin)
		{
			return $this->noPermission();
		}
		
		// get options
		$options = \XF::options();		
		
		// get options from Admin CP -> Options -> Delete posts by username -> Limit
		$limit = $options->deletePostsByUsernameLimit;
		
		// get username
		$username = $this->filter('username', 'str');

        // get result
        $finder = \XF::finder('XF:Post');
        $result = $finder
            ->where('username', $username)
            ->fetchOne();
		
		if (empty($result))
		{
			return $this->error(\XF::phrase('deletepostsbyusername_php_no_posts_found_by_this_username'));
		}
		
		// get posts
		$finder = \XF::finder('XF:Post');
		$posts = $finder
			->with('Thread')
			->with('Thread.Forum')
			->where('username', $username)
			->order('post_id', 'ASC')
			->limit($limit)
			->fetch();
		
		// get postsCount
		$postsCount = count($posts);

		// prepare viewParams
		$viewParams = [
			'username' => $username,
			'postsCount' => $postsCount,
			'limit' => $limit,
			'posts' => $posts
		];
			
		// send to template
		return $this->view('Andy\DeletePostsByUsername:Confirm', 'andy_delete_posts_by_username_confirm', $viewParams);
	}
	
	public function actionDelete()
	{
		// check permission
		if (!\XF::visitor()->is_admin)
		{
			return $this->noPermission();
		}
		
		// get options
		$options = \XF::options();		
		
		// get options from Admin CP -> Options -> Delete posts by username -> Limit
		$limit = $options->deletePostsByUsernameLimit;
		
		// get username
		$username = $this->filter('username', 'str');
		
        // get result
        $finder = \XF::finder('XF:Post');
        $result = $finder
            ->where('username', $username)
            ->fetchOne();
		
		if (empty($result))
		{
			return $this->error(\XF::phrase('deletepostsbyusername_php_no_posts_found_by_this_username'));
		}

        // get posts
        $finder = \XF::finder('XF:Post');
        $posts = $finder
            ->where('username', $username)
            ->order('post_id', 'ASC')
            ->limit($limit)
            ->fetch();
		
		// delete posts
		foreach ($posts AS $k => $v)
		{
            // get postId
			$postId = $v['post_id'];
            
            // get post
            $finder = \XF::finder('XF:Post');
            $post = $finder
                ->where('post_id', $postId)
                ->fetchOne();
			
            // check condition
			if (!empty($post))
			{
				$type = 'hard';
				$reason = '';

				$deleter = \XF::app()->service('XF:Post\Deleter', $post);
				$deleter->delete($type, $reason);
			}
		}
        
        // get posts
        $finder = \XF::finder('XF:Post');
        $posts = $finder
            ->where('username', $username)
            ->order('post_id', 'ASC')
            ->limit($limit)
            ->fetch();
		
		// get postsCount
		$postsCount = count($posts);
		
		// prepare viewParams
		$viewParams = [
			'username' => $username,
			'postsCount' => $postsCount,
			'limit' => $limit,
			'posts' => $posts
		];
			
		// send to template
		return $this->view('Andy\DeletePostsByUsername:Delete', 'andy_delete_posts_by_username_confirm', $viewParams);
	}
}